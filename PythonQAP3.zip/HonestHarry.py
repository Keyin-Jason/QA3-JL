# Description: Honrest Harry car lot sales tracker
# Author: Jason Legge
# Date(s): November 21, 2025


# Define required libraries.
import FormatValues as FV
import datetime
import re
from datetime import datetime, timedelta

# Define program constants.
TRANSFER_FEE_RATE = 0.01
LUXURY_TAX_RATE = 1.6
HST_RATE = 0.15

CUR_DATE = datetime.datetime.now().strftime("%Y-%m-%d")

NUM_YEARS = 4
FINANCE_PER_YEAR = 39.99

# Define program functions.

# Main program starts here.
while True:
    # Gather user inputs.
    CustFirName = input("Enter the customer first name (input END to quit): ").title()
    if CustFirName == "END":
        break

    CustLasName = input("Enter the customer last name: ").title()
    PhoneNum = input("Enter the customer phone number (format: 999-999-9999: ") 
    
    # Validate phone number format
    def validate_PhoneNum(PhoneNum):
       pattern = r'^\d{10}$'
       if re.match(pattern, PhoneNum):
          return True
       return False   
    
    PlateNum = input("Enter the vehicle plate number (format: XXX999): ").upper()
    
    # Validate license plate number format
    def validate_PlateNum(PlateNum):
       pattern = r'^[A-Z]{3}\d{4}$'
       if re.match(pattern, PlateNum):
          return True
       return False
    
    VehMake = input("Enter the vehicle make: ").title()
    VehModel = input("Enter the vehicle model: ").title()
    VehYear = input("Enter the vehicle year (format: YYYY): ")
    
    SellingPrice = float(input("Enter the selling price of the vehicle: $"))
    if SellingPrice > 50000:
        print("*** Error: Selling price cannot exceed $50,000.  ***")
        continue
    
    TradeInValue = float(input("Enter the trade-in value of the vehicle: $"))
    if TradeInValue > SellingPrice:
        print("*** Error: Trade-in value cannot exceed selling price.  ***")
        continue
    
    SalesPerson = input("Enter the salesperson's name: ").title()
    ReceiptNo = CustFirName[0] + CustLasName[0] + "-" + PlateNum[3:7] + "-" + str(PhoneNum)[6:10]
# Perform required calculations.

PriceAfterTradeIn = SellingPrice - TradeInValue
CustFullName = CustFirName(0) + "." " " + CustLasName

LicenseFee = 0
if SellingPrice <= 15000:
    LicenseFee = 75.00
elif SellingPrice > 15000:
   LicenseFee = 150.00
   
TransferFee = 0
if SellingPrice <= 20000:
    TransferFee = SellingPrice * TRANSFER_FEE_RATE
else:
    SellingPrice > 20000
    TransferFee = SellingPrice * LUXURY_TAX_RATE
    
SubTotal = PriceAfterTradeIn + LicenseFee + TransferFee
HSTTax = SubTotal * HST_RATE
TotalPrice = SubTotal + HSTTax

# Payment Schedule Calculation

# Calculate number of months and financing fee
NumOfMonths = NUM_YEARS * 12
Financing_Fee = FINANCE_PER_YEAR * NUM_YEARS
TotalPrice = SubTotal + HSTTax
MonPayment = TotalPrice / NumOfMonths

# Determine the first payment date
today = datetime.now()
if today.day >= 25:
    first_payment_date = (today.replace(day=1) + timedelta(days=32)).replace(day=1)
else:
    first_payment_date = (today.replace(day=1) + timedelta(days=30)).replace(day=1)

# Payment schedule loop
for month in range(NumOfMonths):
    payment_date = first_payment_date + timedelta(days=30 * month)
    print(f"Payment {month + 1}: Date: {payment_date.strftime('%Y-%m-%d')}, Amount: ${MonPayment:.2f}")


# Display results

print()
print()
print("Honest Harry's Car Lot Sales                          Invoice Date:,    {CUR_DATE}")
print("Used Car Sale and Receipt                             Receipt No.:      {ReceiptNo}")
print()
print("                                         Sale Price:              ${SellingPrice:,.2f}")
print("Sold to:"                               "Trade Allowance:         ${TradeInValue:,.2f}")
print("                                    -----------------------------------")
print(f"              {CustFullName:<20s}")
print(f"              {PhoneNum}")
print()
print("                                    -----------------------------------")
       


print("Car Details:  "                     "Subtotal:"      f"${SubTotal:,.2f}")
print("              "                     "HST (15%):"     f"${HSTTax:,.2f}")
print(f"{VehYear}  {VehMake}  {VehModel}"  "----------------------------------")
print()
print("                                " "Total Price:"   f"${TotalPrice:,.2f}")
print()
print("-----------------------------------------------------------------------")
print()
print("                              Financing      Total     Monthly")
print("      # Years   # Payments       Fee        Payments   Payment")
print("      ---------------------------------------------------------")
print(f"        {NUM_YEARS:<5d}   {NumOfMonths:<8d}   ${Financing_Fee:>8.2f}   ${TotalPrice:>10.2f}   ${MonPayment:>8.2f}")
print("      ---------------------------------------------------------")
print()
print()

Continue = input("Would you like to process another sale (Y/N)?: ").upper()
if Continue == "N":
   break