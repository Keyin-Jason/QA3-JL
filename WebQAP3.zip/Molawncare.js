// Desc: Mo Lawncare Customer Invoice Calculator
// Author: Jason Legge
// Dates: November 21, 2025


var $ = function (id) {
  return document.getElementById(id);
};
function displayPhoneNumber(PhoneNo) {
    const formattedNumber = PhoneNo.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
    console.log(formattedNumber);
}

// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});


// Define program constants.
const BORDER_PER_TOT = 0.04; // 4% border charge on total lawn area
const BORDER_RATE_SQ = .28; // $0.28 per square foot border charge

const LAWN_PER_TOT = .95; // 95% of total area is lawn
const LAWN_RATE_SQ = .04; // $0.04 per square foot lawn charge

const FERT_RATE = .03; // $0.03 per square foot fertilizer charge

const HST_RATE = .15; // 15% HST charge
const ENV_TAX_RATE = 1.4; // 1.4% environment tax charge

// Start main program here.

// Gather user input.
let CustName = prompt("Enter the customer name: ");
let StreetAdd = prompt("Enter the street address: ");
let City = prompt("Enter the city: ");
let PhoneNo = prompt("Enter the customer phone number (###-###-####): ");
let LawnSQFeet = prompt("Enter the lawn square footage: ");
LawnSQFeet = parseFloat(LawnSQFeet);

// Calculate program results.
let BorderSQFeet = LawnSQFeet * BORDER_PER_TOT;
let TotalSQFeet = LawnSQFeet + BorderSQFeet;
let LawnCharge = LawnSQFeet * LAWN_RATE_SQ;
let BorderCharge = BorderSQFeet * BORDER_RATE_SQ;
let FertCharge = LawnSQFeet * FERT_RATE;
let SubTotal = LawnCharge + BorderCharge + FertCharge;
let HSTCharge = SubTotal * HST_RATE;
let EnvTaxCharge = SubTotal * (ENV_TAX_RATE / 100);
let TotalDue = SubTotal + HSTCharge + EnvTaxCharge;

// Output results to HTML page.

// Display the results using a table.

// Any HTML tags or Headings are just strings - any varaibles need to be added in a formatted as required.

document.writeln("<table class='motable'>");

document.writeln("<tr>");
document.writeln("<td colspan='2' class='orangeback'><br /><br />Mo's Lawncare Services - Customer Invoice <br /><br /></td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td colspan='2' class='lefttext'> Customer Details: " + "<br />" + "<br />" + CustName + "<br />" + StreetAdd + "<br />" + City  + ", " + PhoneNo + "<br />" + "<br />" + "Proerty size (in sq feet):      " + LawnSQFeet + "<br />" + "<br />" + "</td>");
document.writeln("</tr>")

document.writeln("<tr>");
document.writeln("<td with='225'>Border cost:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(BorderCharge) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td with='225'>Mowing cost:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(LawnCharge) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td with='225'>Fertilizer cost:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(FertCharge) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td></td>");
document.writeln("<td class='righttext'><br /></td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td with='225'>Total charges: </td>");
document.writeln("<td class='righttext'>" + cur2Format.format(SubTotal) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td></td>");
document.writeln("<td class='righttext'><br /></td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td with='225'>Sales Tax (HST): </td>");
document.writeln("<td class='righttext'>" + cur2Format.format(HSTCharge) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td with='225'>Envirnomental Tax: </td>");
document.writeln("<td class='righttext'>" + cur2Format.format(EnvTaxCharge) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td></td>");
document.writeln("<td class='righttext'><br /></td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td with='225'>Invoice Total:</td>");
document.writeln("<td class='righttext'>" + cur2Format.format(TotalDue) + "</td>");
document.writeln("</tr>");

document.writeln("<tr>");
document.writeln("<td colspan='2' class='orangeback'><br /><br />Turning Lawns into Landscapes <br /><br /></td>");
document.writeln("</tr>");

document.writeln("</table>");

// End of program.